//
//  PokemonTabBarController.swift
//  Pokemon App
//
//  Created by Novan Agung Waskito on 10/11/22.
//

import Foundation
import UIKit

class PokemonTabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
