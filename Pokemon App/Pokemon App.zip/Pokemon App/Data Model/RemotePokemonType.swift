//
//  RemotePokemonType.swift
//  Pokemon App
//
//  Created by Novan Agung Waskito on 06/12/22.
//

import Foundation

struct RemotePokemonTypes : Codable {
    let data : [String]
}
