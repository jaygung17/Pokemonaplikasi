//
//  CategoryTypeLoader.swift
//  Pokemon App
//
//  Created by Novan Agung Waskito on 02/12/22.
//

import Foundation
import UIKit

enum PokemonTypeResult {
    case loading(Bool)
    case success([RemotePokemonTypes])
    case failure(String)
}

class CategoryTypeLoader {
    //call API PokemonType
    func getPokemonTypeData (completion: @escaping (PokemonTypeResult) -> Void) {
        let url = URL(string: "https://api.pokemontcg.io/v2/types")!
        URLSession.shared.dataTask(with: url) { [weak self](data, response, error) in
            guard let self = self else { return }
            DispatchQueue.main.async {
                do {
                    let pokemonTypes = try self.transformJsonDataToTypeList(with: data!)
                    completion (.success(pokemonTypes))
                } catch let error {
                    let errorMessage = error.localizedDescription
                    completion (.failure(errorMessage))
                }
            }
        }.resume()
    }
    func transformJsonDataToTypeList(with data: Data) throws -> [[RemotePokemonTypes]] {
        let decoder = JSONDecoder()
        let cardTypes = try decoder.decode(RemotePokemonTypes.self, from: data)
        let pokemonTypes = cardTypes.data as [String]
        return pokemonTypes
        }
        
        }
     

